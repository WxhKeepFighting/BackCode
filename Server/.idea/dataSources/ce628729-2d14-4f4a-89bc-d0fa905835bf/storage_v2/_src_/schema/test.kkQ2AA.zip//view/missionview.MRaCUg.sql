create view missionview as
  select `m`.`id`                   AS `id`,
         `m`.`mission_id`           AS `mission_id`,
         `m`.`mission_applicant_id` AS `mission_applicant_id`,
         `m`.`mission_volunteer_id` AS `mission_volunteer_id`,
         `m`.`mission_event_id`     AS `mission_event_id`,
         `m`.`mission_status`       AS `mission_status`,
         `e`.`event_mean`           AS `event_mean`,
         `e`.`credit`               AS `credit`,
         `s`.`service_stime`        AS `service_stime`,
         `s`.`service_etime`        AS `service_etime`,
         `v`.`v_name`               AS `v_name`,
         `v`.`v_phone`              AS `v_phone`,
         `v`.`v_address`            AS `v_address`,
         `a`.`a_name`               AS `a_name`,
         `a`.`a_age`                AS `a_age`,
         `a`.`a_phone`              AS `a_phone`,
         `a`.`a_address`            AS `a_address`
  from ((((`test`.`mission` `m` join `test`.`service` `s`) join `test`.`event` `e`) join `test`.`user_volunteer` `v`) join `test`.`user_applicant` `a`)
  where ((`m`.`mission_id` = `s`.`mission_id`) and (`m`.`mission_event_id` = `e`.`event_id`) and
         (`m`.`mission_volunteer_id` = `v`.`v_id`) and (`m`.`mission_applicant_id` = `a`.`a_id`));

